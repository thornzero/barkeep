class RPGTooltip extends HTMLElement {
  constructor() {
    super();
    this.attachShadow({ mode: 'open' });
  }

  connectedCallback() {
    // Attributes for the tooltip
    const itemName = this.getAttribute('item-name');
    const itemRarity = this.getAttribute('item-rarity');
    const itemType = this.getAttribute('item-type');
    const itemDescription = this.getAttribute('item-description');
    const itemStats = this.getAttribute('item-stats');

    // Style and HTML template for the component
    this.shadowRoot.innerHTML = \`
      <style>
        .tooltip-card {
          background-color: #333;
          border: 2px solid #444;
          padding: 16px;
          max-width: 300px;
          border-radius: 8px;
          box-shadow: 0 0 10px rgba(0, 0, 0, 0.5);
          font-family: 'Georgia', serif;
          color: #eee;
        }

        .item-name {
          font-size: 20px;
          font-weight: bold;
          color: \${this.getRarityColor(itemRarity)};
          margin-bottom: 8px;
        }

        .item-type {
          font-size: 14px;
          color: #bbb;
          margin-bottom: 12px;
        }

        .item-description {
          font-size: 14px;
          margin-bottom: 12px;
        }

        .item-stats {
          font-size: 12px;
          color: #aaa;
          white-space: pre-wrap;
          border-top: 1px solid #555;
          padding-top: 8px;
        }
      </style>

      <div class="tooltip-card">
        <div class="item-name">\${itemName}</div>
        <div class="item-type">\${itemType}</div>
        <div class="item-description">\${itemDescription}</div>
        <div class="item-stats">\${itemStats}</div>
      </div>
    \`;
  }

  // Method to get color based on item rarity
  getRarityColor(rarity) {
    switch (rarity.toLowerCase()) {
      case 'common':
        return '#c0c0c0';
      case 'uncommon':
        return '#1eff00';
      case 'rare':
        return '#0070dd';
      case 'epic':
        return '#a335ee';
      case 'legendary':
        return '#ff8000';
      default:
        return '#eee';
    }
  }
}

// Define the new web component
customElements.define('rpg-tooltip', RPGTooltip);
